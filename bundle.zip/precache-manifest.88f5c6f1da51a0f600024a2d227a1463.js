self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e882f768655349db206797289c02e92c",
    "url": "/index.html"
  },
  {
    "revision": "49801942e728f253d98f",
    "url": "/static/css/2.4e89ce74.chunk.css"
  },
  {
    "revision": "49a867deace383bac8ac",
    "url": "/static/css/main.5e1c064a.chunk.css"
  },
  {
    "revision": "49801942e728f253d98f",
    "url": "/static/js/2.b7e53983.chunk.js"
  },
  {
    "revision": "49a867deace383bac8ac",
    "url": "/static/js/main.0caee4b3.chunk.js"
  },
  {
    "revision": "1aaf2d167c5770ada209",
    "url": "/static/js/runtime-main.f348fa5a.js"
  },
  {
    "revision": "2c5a24731b9fd7be216810a579710d1f",
    "url": "/static/media/persik.2c5a2473.jpg"
  }
]);